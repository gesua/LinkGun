﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gun : MonoBehaviour
{
    GameObject BulletPrefab;
    public Transform Target; // 마우스 위치

    private void Start()
    {
        BulletPrefab = Resources.Load<GameObject>("Prefabs/Bullet");
        if (BulletPrefab == null)
        {
            Debug.LogError("BulletPrefab 못 찾음");
            return;
        }

        //Target = GameObject.Find("MousePoint").transform;
        if (Target == null)
        {
            Debug.LogError("Target 못 찾음");
            return;
        }
    }

    void Update()
    {
        GameObject tempBullet = Instantiate(BulletPrefab);
        tempBullet.transform.position = transform.position;
        tempBullet.transform.LookAt(Target);
    }
}
